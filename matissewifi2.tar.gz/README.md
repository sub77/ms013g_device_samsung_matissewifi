Device Tree For Samsung Galaxy Grand 2
===================================== 

Basic   | Spec Sheet
-------:|:-------------------------
CPU     | Quad-core 1.2 GHz Cortex-A7
CHIPSET | Qualcomm Snapdragon 400
GPU     | Adreno 305
Memory  | 1.5GB RAM
Shipped Android Version | 4.3 ( Currntly 4.4.2 )
Storage | 8GB
MicroSD | Up to 64GB
Battery | 2600 mAh
Display | 5.2"
Camera  | 8 MP, 3264 x 2448 pixels


![Galaxy Grand 2](http://cdn1.xda-developers.com/devdb/deviceForum/screenshots/2820/20140223T030741.jpg "Galaxy Grand 2")

This branch is for building CyanogenMod 12.0 Firmware.

